package br.ufpb.dcx.diogo.amigosecreto;

public class AmigoJaCadastradoException extends Exception {
    public AmigoJaCadastradoException(String mensagem) {
        super(mensagem);
    }
}
