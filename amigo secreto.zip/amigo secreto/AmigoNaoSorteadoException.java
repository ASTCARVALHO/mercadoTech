package br.ufpb.dcx.diogo.amigosecreto;

public class AmigoNaoSorteadoException extends Exception {
    public AmigoNaoSorteadoException(String mensagem) {
        super(mensagem);
    }
}
